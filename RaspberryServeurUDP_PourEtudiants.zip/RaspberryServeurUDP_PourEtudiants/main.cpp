#include <iostream>
#include "IRServeurUDP.h"

using namespace std;

int main()
{
    return 0;
}